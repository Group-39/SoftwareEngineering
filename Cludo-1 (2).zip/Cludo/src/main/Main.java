/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;




import java.awt.*;
import javax.swing.*;
import java.util.*;



/**
 *
 * @author Dohyun Lee
 */
public final class Main extends javax.swing.JFrame {
    
    String[] players = {"Player1", "Player2", "Player3", "Player4", "Player5", "Player6"};
    String[] characters = {"ColonelMustard", "MissScarlet", "MrGreen", "MrsPeacock", "MrsWhite", "ProfessorPlum"}; 
    String[] weapons = {"Candlestick", "Dagger", "LeadPipe", "Revolver", "Rope", "Spanner"};
    String[] rooms = {"Bathroom", "Bedroom", "Dining Room", "Garden",  "Balcony", "Gym", "HomeOffice", "Library", "Kitchen"};
        
    ArrayList<String> Poppla = new ArrayList<>();
    
    ArrayList<String> PopChr = new ArrayList<>();
    ArrayList<String> PopWeap = new ArrayList<>();
    ArrayList<String> PopRoom = new ArrayList<>();
    
    ArrayList<String> Remaincards = new ArrayList<>();
    
    HashMap<String,String> answerCard = new HashMap<String,String>();
    HashMap<String,Image> image = new HashMap<String,Image>();
    
    int Pnum = -1;
    int Cardnum = -3;
    

    
    public Main() {
        initComponents();
        setSize(1100,850);
        setLocation(0,0);
         ImageIcon myimage = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Board.png")));
        Image mapimg = myimage.getImage().getScaledInstance(map.getWidth(),map.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(mapimg);
        map.setIcon(i);
        
        ImageIcon winimg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("YOU_WIN.png")));
        Image win_img = winimg.getImage().getScaledInstance(win.getWidth(),win.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon WinImg = new ImageIcon(win_img);
        win.setIcon(WinImg);
        win.setVisible(false);
        
        ImageIcon loseimg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("you lose.png")));
        Image lose_img = loseimg.getImage().getScaledInstance(lose.getWidth(),lose.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon LoseImg = new ImageIcon(lose_img);
        lose.setIcon(LoseImg);
        lose.setVisible(false);
        
        
        ImageIcon midlogoImg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo2.png")));
        Image mid_logo = midlogoImg.getImage().getScaledInstance(midlogo.getWidth(),midlogo.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon MidLogo = new ImageIcon(mid_logo);
        midlogo.setIcon(MidLogo);
        
        ImageIcon roomimg1=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Balcony.png")));
        ImageIcon roomimg2=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Bathroom.png")));
        ImageIcon roomimg3=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Bedroom.png")));
        ImageIcon roomimg4=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Dining Room.png")));
        ImageIcon roomimg5=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Garden.png")));
        ImageIcon roomimg6=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Gym.png")));
        ImageIcon roomimg7=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("HomeOffice.png")));
        ImageIcon roomimg8=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Kitchen.png")));
        ImageIcon roomimg9=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Library.png")));
        Image roomimg_1=roomimg1.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_2=roomimg2.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_3=roomimg3.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_4=roomimg4.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_5=roomimg5.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_6=roomimg6.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_7=roomimg7.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_8=roomimg8.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image roomimg_9=roomimg9.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        
        
        
        ImageIcon weapon1=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Candlestick.png")));
        ImageIcon weapon2=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Dagger.png")));
        ImageIcon weapon3=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("LeadPipe.png")));
        ImageIcon weapon4=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Revolver.png")));
        ImageIcon weapon5=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Rope.png")));
        ImageIcon weapon6=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Spanner.png")));
        Image weapon_1=weapon1.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image weapon_2=weapon2.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image weapon_3=weapon3.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image weapon_4=weapon4.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image weapon_5=weapon5.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image weapon_6=weapon6.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        
        ImageIcon character1=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("ColonelMustard.png")));
        ImageIcon character2=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("MissScarlet.png")));
        ImageIcon character3=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("MrGreen.png")));
        ImageIcon character4=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("MrsPeacock.png")));
        ImageIcon character5=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("MrsWhite.png")));
        ImageIcon character6=new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("ProfessorPlum.png")));
        Image character_1=character1.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image character_2=character2.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image character_3=character3.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image character_4=character4.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image character_5=character5.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        Image character_6=character6.getImage().getScaledInstance(Card1.getWidth(),Card1.getHeight(),Image.SCALE_SMOOTH);
        
        image.put("Balcony", roomimg_1);
        image.put("Bathroom", roomimg_2);
        image.put("Bedroom", roomimg_3);
        image.put("Dining Room", roomimg_4);
        image.put("Garden", roomimg_5);
        image.put("Gym", roomimg_6);
        image.put("HomeOffice", roomimg_7);
        image.put("Kitchen", roomimg_8);
        image.put("Library", roomimg_9);
        
        image.put("ColonelMustard", character_1);
        image.put("MissScarlet", character_2);
        image.put("MrGreen", character_3);
        image.put("MrsPeacock", character_4);
        image.put("MrsWhite", character_5);
        image.put("ProfessorPlum", character_6);
        
        image.put("Candlestick", weapon_1);
        image.put("Dagger", weapon_2);
        image.put("LeadPipe", weapon_3);
        image.put("Revolver", weapon_4);
        image.put("Rope", weapon_5);
        image.put("Spanner", weapon_6);
        
        setCard();
        suggestion.setVisible(false);
        suggestion.setEnabled(false);
        accusation.setVisible(false);
        accusation.setEnabled(false);
 
    }
 
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel20 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        Board = new javax.swing.JPanel();
        win = new javax.swing.JLabel();
        lose = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TurnText = new javax.swing.JLabel();
        Player = new javax.swing.JLabel();
        Moves = new javax.swing.JLabel();
        Moves_num = new javax.swing.JLabel();
        Roll_Dice = new javax.swing.JButton();
        PlayerCard = new javax.swing.JLabel();
        Turn = new javax.swing.JButton();
        Card1 = new javax.swing.JLabel();
        Card2 = new javax.swing.JLabel();
        Card3 = new javax.swing.JLabel();
        Exit1 = new javax.swing.JLabel();
        red = new javax.swing.JPanel();
        green = new javax.swing.JPanel();
        blue = new javax.swing.JPanel();
        purple = new javax.swing.JPanel();
        brown = new javax.swing.JPanel();
        white = new javax.swing.JPanel();
        standard = new javax.swing.JPanel();
        up = new javax.swing.JButton();
        left = new javax.swing.JButton();
        right = new javax.swing.JButton();
        down = new javax.swing.JButton();
        Door1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Door2 = new javax.swing.JLabel();
        Door3 = new javax.swing.JLabel();
        Door4 = new javax.swing.JLabel();
        Door5 = new javax.swing.JLabel();
        Door6 = new javax.swing.JLabel();
        Door8 = new javax.swing.JLabel();
        Door7 = new javax.swing.JLabel();
        Door9 = new javax.swing.JLabel();
        Door10 = new javax.swing.JLabel();
        Door11 = new javax.swing.JLabel();
        Door12 = new javax.swing.JLabel();
        Door15 = new javax.swing.JLabel();
        Door14 = new javax.swing.JLabel();
        Door16 = new javax.swing.JLabel();
        Door13 = new javax.swing.JLabel();
        wall1 = new javax.swing.JLabel();
        wall2 = new javax.swing.JLabel();
        wall3 = new javax.swing.JLabel();
        wall4 = new javax.swing.JLabel();
        wall5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        wall22 = new javax.swing.JLabel();
        wall23 = new javax.swing.JLabel();
        room1 = new javax.swing.JLabel();
        room2 = new javax.swing.JLabel();
        room3 = new javax.swing.JLabel();
        room4 = new javax.swing.JLabel();
        room6 = new javax.swing.JLabel();
        room5 = new javax.swing.JLabel();
        room7 = new javax.swing.JLabel();
        room8 = new javax.swing.JLabel();
        room9 = new javax.swing.JLabel();
        midlogo = new javax.swing.JLabel();
        map = new javax.swing.JLabel();
        suggestion = new javax.swing.JButton();
        suggest1 = new javax.swing.JTextField();
        suggest2 = new javax.swing.JTextField();
        suggest3 = new javax.swing.JTextField();
        result1 = new javax.swing.JLabel();
        result2 = new javax.swing.JLabel();
        result3 = new javax.swing.JLabel();
        accusation = new javax.swing.JButton();

        jLabel20.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel20.setText("Dining");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Board.setBackground(new java.awt.Color(255, 250, 230));
        Board.setName("Board"); // NOI18N
        Board.setLayout(null);
        Board.add(win);
        win.setBounds(740, 220, 360, 200);
        Board.add(lose);
        lose.setBounds(740, 220, 360, 200);

        jLabel2.setFont(new java.awt.Font("SansSerif", 3, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 0, 51));
        jLabel2.setText("Group_39");
        Board.add(jLabel2);
        jLabel2.setBounds(250, 10, 230, 40);

        TurnText.setFont(new java.awt.Font("SansSerif", 3, 14)); // NOI18N
        TurnText.setText("Turn");
        Board.add(TurnText);
        TurnText.setBounds(781, 64, 50, 20);
        TurnText.getAccessibleContext().setAccessibleName("Turn :");

        Player.setFont(new java.awt.Font("굴림", 1, 15)); // NOI18N
        Player.setText("NULL");
        Board.add(Player);
        Player.setBounds(840, 64, 80, 20);

        Moves.setFont(new java.awt.Font("굴림", 1, 15)); // NOI18N
        Moves.setText("Moves");
        Board.add(Moves);
        Moves.setBounds(780, 140, 50, 18);

        Moves_num.setText("0");
        Board.add(Moves_num);
        Moves_num.setBounds(840, 140, 80, 18);

        Roll_Dice.setBackground(new java.awt.Color(102, 0, 51));
        Roll_Dice.setFont(new java.awt.Font("SansSerif", 3, 15)); // NOI18N
        Roll_Dice.setForeground(new java.awt.Color(255, 255, 255));
        Roll_Dice.setText("Roll Dice");
        Roll_Dice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Roll_DiceActionPerformed(evt);
            }
        });
        Board.add(Roll_Dice);
        Roll_Dice.setBounds(780, 180, 100, 31);

        PlayerCard.setFont(new java.awt.Font("굴림", 3, 15)); // NOI18N
        PlayerCard.setText("Player Card");
        Board.add(PlayerCard);
        PlayerCard.setBounds(780, 580, 100, 18);

        Turn.setBackground(new java.awt.Color(153, 0, 51));
        Turn.setFont(new java.awt.Font("SansSerif", 3, 15)); // NOI18N
        Turn.setForeground(new java.awt.Color(255, 255, 255));
        Turn.setText("Start");
        Turn.setToolTipText("");
        Turn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TurnActionPerformed(evt);
            }
        });
        Board.add(Turn);
        Turn.setBounds(780, 90, 110, 31);

        Card1.setFont(new java.awt.Font("Arial", 3, 15)); // NOI18N
        Card1.setText("Card 1");
        Card1.setPreferredSize(new java.awt.Dimension(46, 46));
        Board.add(Card1);
        Card1.setBounds(780, 620, 70, 140);

        Card2.setFont(new java.awt.Font("Arial", 3, 15)); // NOI18N
        Card2.setText("Card 2");
        Board.add(Card2);
        Card2.setBounds(860, 620, 70, 140);

        Card3.setFont(new java.awt.Font("Arial", 3, 15)); // NOI18N
        Card3.setText("Card 3");
        Board.add(Card3);
        Card3.setBounds(940, 620, 70, 140);

        Exit1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/icons8-cancel 2.png"))); // NOI18N
        Exit1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Exit1MousePressed(evt);
            }
        });
        Board.add(Exit1);
        Exit1.setBounds(973, 12, 25, 43);

        red.setBackground(new java.awt.Color(255, 0, 51));
        red.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        red.setName("red"); // NOI18N

        javax.swing.GroupLayout redLayout = new javax.swing.GroupLayout(red);
        red.setLayout(redLayout);
        redLayout.setHorizontalGroup(
            redLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        redLayout.setVerticalGroup(
            redLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(red);
        red.setBounds(716, 228, 22, 22);
        red.getAccessibleContext().setAccessibleName("Red");

        green.setBackground(new java.awt.Color(0, 204, 102));
        green.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        green.setName("green"); // NOI18N

        javax.swing.GroupLayout greenLayout = new javax.swing.GroupLayout(green);
        green.setLayout(greenLayout);
        greenLayout.setHorizontalGroup(
            greenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        greenLayout.setVerticalGroup(
            greenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(green);
        green.setBounds(48, 292, 22, 22);

        blue.setBackground(new java.awt.Color(0, 0, 255));
        blue.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        blue.setForeground(new java.awt.Color(0, 51, 255));
        blue.setName("blue"); // NOI18N

        javax.swing.GroupLayout blueLayout = new javax.swing.GroupLayout(blue);
        blue.setLayout(blueLayout);
        blueLayout.setHorizontalGroup(
            blueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        blueLayout.setVerticalGroup(
            blueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(blue);
        blue.setBounds(240, 68, 22, 22);

        purple.setBackground(new java.awt.Color(204, 0, 204));
        purple.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        purple.setName("purple"); // NOI18N

        javax.swing.GroupLayout purpleLayout = new javax.swing.GroupLayout(purple);
        purple.setLayout(purpleLayout);
        purpleLayout.setHorizontalGroup(
            purpleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        purpleLayout.setVerticalGroup(
            purpleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(purple);
        purple.setBounds(528, 740, 22, 22);

        brown.setBackground(new java.awt.Color(153, 0, 51));
        brown.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        brown.setName("brown"); // NOI18N

        javax.swing.GroupLayout brownLayout = new javax.swing.GroupLayout(brown);
        brown.setLayout(brownLayout);
        brownLayout.setHorizontalGroup(
            brownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        brownLayout.setVerticalGroup(
            brownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(brown);
        brown.setBounds(304, 740, 22, 22);

        white.setBackground(new java.awt.Color(255, 255, 255));
        white.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        white.setName("white"); // NOI18N

        javax.swing.GroupLayout whiteLayout = new javax.swing.GroupLayout(white);
        white.setLayout(whiteLayout);
        whiteLayout.setHorizontalGroup(
            whiteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );
        whiteLayout.setVerticalGroup(
            whiteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        Board.add(white);
        white.setBounds(716, 580, 22, 22);

        standard.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout standardLayout = new javax.swing.GroupLayout(standard);
        standard.setLayout(standardLayout);
        standardLayout.setHorizontalGroup(
            standardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        standardLayout.setVerticalGroup(
            standardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        Board.add(standard);
        standard.setBounds(0, 0, 10, 10);

        up.setBackground(new java.awt.Color(102, 0, 51));
        up.setFont(new java.awt.Font("굴림", 0, 8)); // NOI18N
        up.setForeground(new java.awt.Color(255, 255, 255));
        up.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upActionPerformed(evt);
            }
        });
        Board.add(up);
        up.setBounds(820, 260, 40, 40);

        left.setBackground(new java.awt.Color(102, 0, 51));
        left.setFont(new java.awt.Font("굴림", 0, 10)); // NOI18N
        left.setForeground(new java.awt.Color(255, 255, 255));
        left.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leftActionPerformed(evt);
            }
        });
        Board.add(left);
        left.setBounds(780, 300, 40, 40);

        right.setBackground(new java.awt.Color(102, 0, 51));
        right.setFont(new java.awt.Font("굴림", 0, 10)); // NOI18N
        right.setForeground(new java.awt.Color(255, 255, 255));
        right.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rightActionPerformed(evt);
            }
        });
        Board.add(right);
        right.setBounds(860, 300, 40, 40);

        down.setBackground(new java.awt.Color(102, 0, 51));
        down.setFont(new java.awt.Font("굴림", 0, 10)); // NOI18N
        down.setForeground(new java.awt.Color(255, 255, 255));
        down.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                downActionPerformed(evt);
            }
        });
        Board.add(down);
        down.setBounds(820, 340, 40, 40);

        Door1.setName("Door"); // NOI18N
        Board.add(Door1);
        Door1.setBounds(171, 191, 32, 32);

        jLabel3.setName("Door"); // NOI18N
        Board.add(jLabel3);
        jLabel3.setBounds(171, 191, 32, 32);

        jLabel4.setName("Door"); // NOI18N
        Board.add(jLabel4);
        jLabel4.setBounds(171, 191, 32, 32);

        Door2.setName("Door"); // NOI18N
        Board.add(Door2);
        Door2.setBounds(267, 127, 32, 32);

        Door3.setName("Door"); // NOI18N
        Board.add(Door3);
        Door3.setBounds(331, 191, 64, 32);

        Door4.setName("Door"); // NOI18N
        Board.add(Door4);
        Door4.setBounds(523, 159, 32, 32);

        Door5.setName("Door"); // NOI18N
        Board.add(Door5);
        Door5.setBounds(523, 319, 32, 32);

        Door6.setName("Door"); // NOI18N
        Board.add(Door6);
        Door6.setBounds(619, 351, 32, 32);

        Door8.setName("Door"); // NOI18N
        Board.add(Door8);
        Door8.setBounds(523, 484, 32, 32);

        Door7.setName("Door"); // NOI18N
        Board.add(Door7);
        Door7.setBounds(683, 420, 32, 32);

        Door9.setName("Door"); // NOI18N
        Board.add(Door9);
        Door9.setBounds(555, 607, 32, 32);

        Door10.setName("Door"); // NOI18N
        Board.add(Door10);
        Door10.setBounds(235, 575, 32, 32);

        Door11.setName("Door"); // NOI18N
        Board.add(Door11);
        Door11.setBounds(235, 415, 32, 32);

        Door12.setName("Door"); // NOI18N
        Board.add(Door12);
        Door12.setBounds(203, 319, 32, 32);

        Door15.setName("Door"); // NOI18N
        Board.add(Door15);
        Door15.setBounds(331, 575, 32, 32);

        Door14.setName("Door"); // NOI18N
        Board.add(Door14);
        Door14.setBounds(435, 575, 32, 32);

        Door16.setName("Door"); // NOI18N
        Board.add(Door16);
        Door16.setBounds(331, 639, 32, 32);

        Door13.setName("Door"); // NOI18N
        Board.add(Door13);
        Door13.setBounds(435, 671, 32, 32);

        wall1.setName("wall"); // NOI18N
        Board.add(wall1);
        wall1.setBounds(43, 191, 160, 32);

        wall2.setName("wall"); // NOI18N
        Board.add(wall2);
        wall2.setBounds(171, 63, 32, 160);

        wall3.setName("wall"); // NOI18N
        Board.add(wall3);
        wall3.setBounds(267, 63, 32, 160);

        wall4.setName("wall"); // NOI18N
        Board.add(wall4);
        wall4.setBounds(267, 191, 200, 32);

        wall5.setName("wall"); // NOI18N
        Board.add(wall5);
        wall5.setBounds(435, 63, 32, 160);

        jLabel1.setName("wall"); // NOI18N
        Board.add(jLabel1);
        jLabel1.setBounds(523, 63, 32, 128);

        jLabel5.setName("wall"); // NOI18N
        Board.add(jLabel5);
        jLabel5.setBounds(523, 159, 224, 32);

        jLabel6.setName("wall"); // NOI18N
        Board.add(jLabel6);
        jLabel6.setBounds(523, 255, 224, 32);

        jLabel7.setName("wall"); // NOI18N
        Board.add(jLabel7);
        jLabel7.setBounds(523, 255, 32, 128);

        jLabel8.setName("wall"); // NOI18N
        Board.add(jLabel8);
        jLabel8.setBounds(523, 351, 224, 32);

        jLabel9.setName("wall"); // NOI18N
        Board.add(jLabel9);
        jLabel9.setBounds(523, 420, 224, 32);

        jLabel10.setName("wall"); // NOI18N
        Board.add(jLabel10);
        jLabel10.setBounds(523, 420, 32, 128);

        jLabel11.setName("wall"); // NOI18N
        Board.add(jLabel11);
        jLabel11.setBounds(523, 516, 224, 32);
        Board.add(jLabel12);
        jLabel12.setBounds(555, 607, 192, 32);

        jLabel13.setName("wall"); // NOI18N
        Board.add(jLabel13);
        jLabel13.setBounds(555, 607, 32, 160);

        jLabel14.setName("wall"); // NOI18N
        Board.add(jLabel14);
        jLabel14.setBounds(435, 575, 32, 192);

        jLabel15.setName("wall"); // NOI18N
        Board.add(jLabel15);
        jLabel15.setBounds(331, 575, 136, 32);

        jLabel16.setName("wall"); // NOI18N
        Board.add(jLabel16);
        jLabel16.setBounds(331, 575, 32, 192);

        jLabel17.setName("wal"); // NOI18N
        Board.add(jLabel17);
        jLabel17.setBounds(235, 575, 32, 192);

        jLabel18.setName("wall"); // NOI18N
        Board.add(jLabel18);
        jLabel18.setBounds(43, 575, 192, 32);

        jLabel19.setName("wall"); // NOI18N
        Board.add(jLabel19);
        jLabel19.setBounds(43, 447, 224, 32);

        jLabel21.setName("wall"); // NOI18N
        Board.add(jLabel21);
        jLabel21.setBounds(235, 319, 32, 160);

        wall22.setName("wall"); // NOI18N
        Board.add(wall22);
        wall22.setBounds(43, 319, 224, 32);

        wall23.setName("wall"); // NOI18N
        Board.add(wall23);
        wall23.setBounds(331, 287, 136, 224);

        room1.setName("Room"); // NOI18N
        Board.add(room1);
        room1.setBounds(43, 63, 160, 160);

        room2.setName("Room"); // NOI18N
        Board.add(room2);
        room2.setBounds(267, 63, 200, 160);

        room3.setName("Room"); // NOI18N
        Board.add(room3);
        room3.setBounds(523, 63, 224, 128);

        room4.setName("Room"); // NOI18N
        Board.add(room4);
        room4.setBounds(523, 255, 224, 128);

        room6.setName("Room"); // NOI18N
        Board.add(room6);
        room6.setBounds(555, 607, 192, 160);

        room5.setName("Room"); // NOI18N
        Board.add(room5);
        room5.setBounds(523, 420, 224, 128);

        room7.setName("Room"); // NOI18N
        Board.add(room7);
        room7.setBounds(331, 575, 136, 192);

        room8.setName("Room"); // NOI18N
        Board.add(room8);
        room8.setBounds(43, 575, 224, 192);

        room9.setBackground(new java.awt.Color(255, 255, 255));
        room9.setName("Room"); // NOI18N
        Board.add(room9);
        room9.setBounds(43, 319, 224, 160);

        midlogo.setName("wall"); // NOI18N
        Board.add(midlogo);
        midlogo.setBounds(331, 287, 128, 224);

        map.setName("Board"); // NOI18N
        Board.add(map);
        map.setBounds(43, 63, 704, 704);

        suggestion.setBackground(new java.awt.Color(102, 153, 255));
        suggestion.setText("suggestion");
        suggestion.setActionCommand("suggetion");
        suggestion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suggestionActionPerformed(evt);
            }
        });
        Board.add(suggestion);
        suggestion.setBounds(780, 430, 110, 27);

        suggest1.setText("Character");
        suggest1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suggest1ActionPerformed(evt);
            }
        });
        Board.add(suggest1);
        suggest1.setBounds(780, 490, 80, 25);

        suggest2.setText("Weapon");
        Board.add(suggest2);
        suggest2.setBounds(780, 520, 80, 25);

        suggest3.setText("Room");
        Board.add(suggest3);
        suggest3.setBounds(780, 550, 80, 25);

        result1.setFont(new java.awt.Font("굴림", 1, 15)); // NOI18N
        result1.setText("result1");
        Board.add(result1);
        result1.setBounds(870, 490, 80, 25);

        result2.setFont(new java.awt.Font("굴림", 1, 15)); // NOI18N
        result2.setText("result2");
        Board.add(result2);
        result2.setBounds(870, 520, 80, 25);

        result3.setFont(new java.awt.Font("굴림", 1, 15)); // NOI18N
        result3.setText("result3");
        Board.add(result3);
        result3.setBounds(870, 550, 80, 25);

        accusation.setBackground(new java.awt.Color(255, 102, 102));
        accusation.setText("Accusation");
        accusation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accusationActionPerformed(evt);
            }
        });
        Board.add(accusation);
        accusation.setBounds(780, 460, 110, 27);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Board, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Board, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public void setCard(){
        
    for (int i = 0; i < players.length; i ++) {
            Poppla.add(players[i]);
        }
        
    for (int i = 0; i < characters.length; i ++) {
            PopChr.add(characters[i]);
        }
    for (int i = 0; i < weapons.length; i ++) {
            PopWeap.add(weapons[i]);
        }
    for (int i = 0; i < rooms.length; i ++) {
            PopRoom.add(rooms[i]);
        }
      
        Collections.shuffle(PopChr);
        Collections.shuffle(PopWeap);
        Collections.shuffle(PopRoom);
             
      answerCard.put("chr",PopChr.get(0));
      answerCard.put("weapon",PopWeap.get(0));
      answerCard.put("room",PopRoom.get(0));
      PopChr.remove(0);
      PopWeap.remove(0);
      PopRoom.remove(0);
      
        Remaincards.addAll(PopChr);
        Remaincards.addAll(PopWeap);
        Remaincards.addAll(PopRoom);
        Collections.shuffle(Remaincards);
      
    }
    public int roll_dice(){
        int dice1 = (int) (Math.random() * 6) + 1;
        int dice2 = (int) (Math.random() * 6) + 1;
        int sum_dice = dice1 + dice2;
        return sum_dice;
    } 
    private void Roll_DiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Roll_DiceActionPerformed
        // TODO add your handling code here:
        int num;
        num = roll_dice();
        Roll_Dice.setText(""+num);
        Moves_num.setText(""+num);
        standard.setLocation(num, num);
    }//GEN-LAST:event_Roll_DiceActionPerformed

    private void Exit1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Exit1MousePressed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_Exit1MousePressed

    public Component findToken(){
        Component aComponent = standard;
        if(Player.getText().equals("Player1")){
            aComponent = Board.findComponentAt(red.getX()+1, red.getY()+1);
        }
        if(Player.getText().equals("Player2")){
            aComponent = Board.findComponentAt(white.getX()+1, white.getY()+1);
        }
        if(Player.getText().equals("Player3")){
            aComponent = Board.findComponentAt(purple.getX()+1, purple.getY()+1);
        }
        if(Player.getText().equals("Player4")){
            aComponent = Board.findComponentAt(brown.getX()+1, brown.getY()+1);
        }
        if(Player.getText().equals("Player5")){
            aComponent = Board.findComponentAt(green.getX()+1, green.getY()+1);
        }
        if(Player.getText().equals("Player6")){
            aComponent = Board.findComponentAt(blue.getX()+1, blue.getY()+1);
        }
        return aComponent;
    }
    private void upActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upActionPerformed
        // TODO add your handling code here: 
        if(standard.getX()>0){
            if( 63 <= findToken().getY()-32 && !"wall".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()-32).getName())){
                findToken().setLocation(findToken().getX(), findToken().getY()-32);
                standard.setLocation(standard.getX()-1, WIDTH);
                
                if("Door".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(0, WIDTH);
                        suggestion.setVisible(true);
                        suggestion.setEnabled(true);
                        accusation.setVisible(true);
                        accusation.setEnabled(true);
                    }
                
                if("Room".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(standard.getX()+1, WIDTH);
                    }
                Moves_num.setText(""+standard.getX());
                if(Moves_num.getText().equals("0")){
                    Roll_Dice.setVisible(false);
                }
            }
        }
    }//GEN-LAST:event_upActionPerformed

    private void downActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downActionPerformed
        // TODO add your handling code here:
        if(standard.getX()>0){
            if( findToken().getY()+64 <= 780 && !"wall".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()+32).getName())){
                findToken().setLocation(findToken().getX(), findToken().getY()+32);
                standard.setLocation(standard.getX()-1, WIDTH);
                
                if("Door".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(0, WIDTH);
                        suggestion.setVisible(true);
                        suggestion.setEnabled(true);
                        accusation.setVisible(true);
                        accusation.setEnabled(true);
                    }
                
                if("Room".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(standard.getX()+1, WIDTH);
                    }
                Moves_num.setText(""+standard.getX());
                if(Moves_num.getText().equals("0")){
                    Roll_Dice.setVisible(false);
                }
            }
        }
        
    }//GEN-LAST:event_downActionPerformed

    private void leftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leftActionPerformed
        // TODO add your handling code here:
        if(standard.getX()>0){
            if( 43 <= findToken().getX()-31 && !"wall".equals(Board.getComponentAt(findToken().getX()-6, findToken().getY()).getName())){
                findToken().setLocation(findToken().getX()-31, findToken().getY());
                standard.setLocation(standard.getX()-1, WIDTH);
                
                if("Door".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(0, WIDTH);
                        suggestion.setVisible(true);
                        suggestion.setEnabled(true);
                        accusation.setVisible(true);
                        accusation.setEnabled(true);
                    }
                
                if("Room".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(standard.getX()+1, WIDTH);
                    }
                Moves_num.setText(""+standard.getX());
                if(Moves_num.getText().equals("0")){
                    Roll_Dice.setVisible(false);
                }
            }
        }
    }//GEN-LAST:event_leftActionPerformed

    private void rightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rightActionPerformed
        // TODO add your handling code here:       
        if(standard.getX()>0){
                if( findToken().getX()+62 <= 760 && !"wall".equals(Board.getComponentAt(findToken().getX()+54, findToken().getY()).getName())){
                findToken().setLocation(findToken().getX()+31, findToken().getY());                
                standard.setLocation(standard.getX()-1, WIDTH);
                
                if("Door".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(0, WIDTH);
                        suggestion.setVisible(true);
                        suggestion.setEnabled(true);
                        accusation.setVisible(true);
                        accusation.setEnabled(true);
                    }
                
                if("Room".equals(Board.getComponentAt(findToken().getX()+23, findToken().getY()).getName())){
                        standard.setLocation(standard.getX()+1, WIDTH);
                    }
                Moves_num.setText(""+standard.getX());
                if(Moves_num.getText().equals("0")){
                    Roll_Dice.setVisible(false);
                }
                }
            }
    }//GEN-LAST:event_rightActionPerformed

    private void TurnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TurnActionPerformed
        // TODO add your handling code here:
        Roll_Dice.setVisible(true);
        Roll_Dice.setText("Roll Dice");
        Turn.setText("End Turn");
        suggestion.setVisible(false);
        accusation.setVisible(false);
        lose.setVisible(false);
        standard.setLocation(0, WIDTH);
        Moves_num.setText(""+standard.getX());
        if(Pnum < Poppla.size()-1){
            Pnum += 1;
            Cardnum += 3;
            Player.setText(Poppla.get(Pnum));
            Card1.setText(Remaincards.get(Cardnum));
            Card2.setText(Remaincards.get(Cardnum+1));
            Card3.setText(Remaincards.get(Cardnum+2));
        }
        else{
            Pnum -= Poppla.size()-1;
            Cardnum -= Remaincards.size()-3;
            Player.setText(Poppla.get(Pnum));
            Card1.setText(Remaincards.get(Cardnum));
            Card2.setText(Remaincards.get(Cardnum+1));
            Card3.setText(Remaincards.get(Cardnum+2));
        }
        ImageIcon card_a = new ImageIcon(image.get(Card1.getText()));
        ImageIcon card_b = new ImageIcon(image.get(Card2.getText()));
        ImageIcon card_c = new ImageIcon(image.get(Card3.getText()));
        
        Card1.setIcon(card_a);
        Card2.setIcon(card_b);
        Card3.setIcon(card_c); 
        
    }//GEN-LAST:event_TurnActionPerformed

    public boolean isCorrect(String a, String b){
        return answerCard.get(a).equals(b);
    }
    private void suggestionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suggestionActionPerformed
        // TODO add your handling code here:
            result1.setText("" + !isCorrect("chr", suggest1.getText()));
            result2.setText("" + !isCorrect("weapon", suggest2.getText()));
            result3.setText("" + !isCorrect("room", suggest3.getText()));
    }//GEN-LAST:event_suggestionActionPerformed

    private void suggest1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suggest1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_suggest1ActionPerformed

    public int ia(){
        int a = 0;
    for(int i = 0; i < Poppla.size(); i++ ){
        if(Poppla.get(i).equals(Player.getText())){
            a = i;
        }
    }
    return a;
}
    private void accusationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accusationActionPerformed
        // TODO add your handling code here:
        if(isCorrect("chr", suggest1.getText()) && isCorrect("weapon", suggest2.getText()) && isCorrect("room", suggest3.getText())){
            result1.setText("Correct");
            win.setVisible(true);
        }
        else{
            result1.setText("Wrong");
            Poppla.remove(ia());
            Remaincards.remove(ia());
            Remaincards.remove(ia()+1);
            Remaincards.remove(ia()+2);
            Pnum -= 1;
            Cardnum -= 3;
            lose.setVisible(true);
        }
    }//GEN-LAST:event_accusationActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Board;
    private javax.swing.JLabel Card1;
    private javax.swing.JLabel Card2;
    private javax.swing.JLabel Card3;
    private javax.swing.JLabel Door1;
    private javax.swing.JLabel Door10;
    private javax.swing.JLabel Door11;
    private javax.swing.JLabel Door12;
    private javax.swing.JLabel Door13;
    private javax.swing.JLabel Door14;
    private javax.swing.JLabel Door15;
    private javax.swing.JLabel Door16;
    private javax.swing.JLabel Door2;
    private javax.swing.JLabel Door3;
    private javax.swing.JLabel Door4;
    private javax.swing.JLabel Door5;
    private javax.swing.JLabel Door6;
    private javax.swing.JLabel Door7;
    private javax.swing.JLabel Door8;
    private javax.swing.JLabel Door9;
    private javax.swing.JLabel Exit1;
    private javax.swing.JLabel Moves;
    private javax.swing.JLabel Moves_num;
    private javax.swing.JLabel Player;
    private javax.swing.JLabel PlayerCard;
    private javax.swing.JButton Roll_Dice;
    private javax.swing.JButton Turn;
    private javax.swing.JLabel TurnText;
    private javax.swing.JButton accusation;
    private javax.swing.JPanel blue;
    private javax.swing.JPanel brown;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton down;
    private javax.swing.JPanel green;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton left;
    private javax.swing.JLabel lose;
    private javax.swing.JLabel map;
    private javax.swing.JLabel midlogo;
    private javax.swing.JPanel purple;
    private javax.swing.JPanel red;
    private javax.swing.JLabel result1;
    private javax.swing.JLabel result2;
    private javax.swing.JLabel result3;
    private javax.swing.JButton right;
    private javax.swing.JLabel room1;
    private javax.swing.JLabel room2;
    private javax.swing.JLabel room3;
    private javax.swing.JLabel room4;
    private javax.swing.JLabel room5;
    private javax.swing.JLabel room6;
    private javax.swing.JLabel room7;
    private javax.swing.JLabel room8;
    private javax.swing.JLabel room9;
    private javax.swing.JPanel standard;
    private javax.swing.JTextField suggest1;
    private javax.swing.JTextField suggest2;
    private javax.swing.JTextField suggest3;
    private javax.swing.JButton suggestion;
    private javax.swing.JButton up;
    private javax.swing.JLabel wall1;
    private javax.swing.JLabel wall2;
    private javax.swing.JLabel wall22;
    private javax.swing.JLabel wall23;
    private javax.swing.JLabel wall3;
    private javax.swing.JLabel wall4;
    private javax.swing.JLabel wall5;
    private javax.swing.JPanel white;
    private javax.swing.JLabel win;
    // End of variables declaration//GEN-END:variables
}
